import { useState } from 'react';
import { 
  ShieldAlert, 
  AlertTriangle, 
  RefreshCw, 
  CheckCircle2, 
  Activity, 
  Database, 
  Server, 
  Lock, 
  Unlock,
  Radio
} from 'lucide-react';
import { FRAUD_ALERTS } from '../../data/mockFintechData';
import { FraudAlertItem } from '../../types';

export const CroDashboard = () => {
  const [alerts, setAlerts] = useState<FraudAlertItem[]>(FRAUD_ALERTS);
  const [isDrillRunning, setIsDrillRunning] = useState(false);
  const [drillResult, setDrillResult] = useState<string | null>(null);

  const runDisasterRecoveryDrill = () => {
    setIsDrillRunning(true);
    setDrillResult(null);
    setTimeout(() => {
      setIsDrillRunning(false);
      setDrillResult('Automated switchover to Secondary Cluster eu-west-1-b completed in 11.8s. All transactions persisted without packet loss.');
      setTimeout(() => setDrillResult(null), 8000);
    }, 2000);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Top Banner */}
      <div className="p-5 rounded-2xl bg-gradient-to-r from-slate-900 via-slate-900 to-rose-950/40 border border-slate-800 shadow-xl flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 text-[11px] font-semibold bg-rose-500/10 text-rose-400 border border-rose-500/30 rounded-full">
              CRO Risk Management Command
            </span>
            <span className="text-xs text-slate-400">admin.ifuturewallet.com • Threat Vector Analysis</span>
          </div>
          <h1 className="text-xl md:text-2xl font-bold tracking-tight text-white">
            Fraud Sentinel, Anomaly Detection & Business Continuity
          </h1>
          <p className="text-xs text-slate-400 max-w-2xl">
            Real-time biometric anomaly alerts, device fingerprinting, brute-force mitigation, and automated disaster recovery tests.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={runDisasterRecoveryDrill}
            disabled={isDrillRunning}
            className="px-3.5 py-2 text-xs font-semibold bg-rose-500 hover:bg-rose-400 text-white rounded-lg flex items-center gap-2 shadow-lg shadow-rose-500/15 transition-all disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isDrillRunning ? 'animate-spin' : ''}`} />
            {isDrillRunning ? 'Simulating Failover...' : 'Execute DR Failover Drill'}
          </button>
        </div>
      </div>

      {drillResult && (
        <div className="p-4 bg-emerald-500/10 border border-emerald-500/30 rounded-xl text-xs text-emerald-300 flex items-center gap-2.5 animate-in fade-in">
          <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
          <span>{drillResult}</span>
        </div>
      )}

      {/* Fraud KPIs */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3.5">
        <div className="p-4 bg-slate-900 rounded-xl border border-slate-800">
          <span className="text-xs text-slate-400 block">Fraud Alerts Today</span>
          <span className="text-xl font-bold text-amber-400 font-mono mt-1 block">14</span>
          <span className="text-[11px] text-emerald-400">100% Mitigated at Edge</span>
        </div>
        <div className="p-4 bg-slate-900 rounded-xl border border-slate-800">
          <span className="text-xs text-slate-400 block">Blocked Fraud Attempts</span>
          <span className="text-xl font-bold text-rose-400 font-mono mt-1 block">428</span>
          <span className="text-[11px] text-slate-500">Cred-stuffing & SIM swap</span>
        </div>
        <div className="p-4 bg-slate-900 rounded-xl border border-slate-800">
          <span className="text-xs text-slate-400 block">Auto-Frozen Accounts</span>
          <span className="text-xl font-bold text-white font-mono mt-1 block">19</span>
          <span className="text-[11px] text-slate-500">Awaiting 2FA step-up</span>
        </div>
        <div className="p-4 bg-slate-900 rounded-xl border border-slate-800">
          <span className="text-xs text-slate-400 block">Platform Risk Index</span>
          <span className="text-xl font-bold text-emerald-400 font-mono mt-1 block">9.4 / 100</span>
          <span className="text-[11px] text-slate-500">Low Risk Threshold &lt; 25</span>
        </div>
      </div>

      {/* Real-Time Fraud Incidents Stream */}
      <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-semibold text-slate-100 flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-rose-400" />
            Active Anomaly & Fraud Incident Stream
          </h3>
          <span className="flex items-center gap-1.5 text-xs text-emerald-400">
            <Radio className="w-3.5 h-3.5 animate-pulse" /> Live Telemetry
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400">
                <th className="pb-3 font-medium">Attack Vector</th>
                <th className="pb-3 font-medium">Target Account</th>
                <th className="pb-3 font-medium">IP Address / Geo</th>
                <th className="pb-3 font-medium">Severity</th>
                <th className="pb-3 font-medium">Automated Response</th>
                <th className="pb-3 font-medium">Timestamp</th>
                <th className="pb-3 font-medium text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-850">
              {alerts.map((alert) => (
                <tr key={alert.id} className="hover:bg-slate-850/40 transition-colors">
                  <td className="py-3 font-semibold text-slate-200">{alert.eventType}</td>
                  <td className="py-3 font-mono text-cyan-400">{alert.affectedAccount}</td>
                  <td className="py-3 text-slate-300">
                    <span className="font-mono text-slate-400">{alert.ipAddress}</span> ({alert.location})
                  </td>
                  <td className="py-3">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                        alert.severity === 'Critical'
                          ? 'bg-rose-500/20 text-rose-300'
                          : 'bg-amber-500/20 text-amber-300'
                      }`}
                    >
                      {alert.severity}
                    </span>
                  </td>
                  <td className="py-3 text-emerald-400 font-mono">{alert.actionTaken}</td>
                  <td className="py-3 text-slate-400">{alert.timestamp}</td>
                  <td className="py-3 text-right">
                    <button className="px-2.5 py-1 bg-slate-800 hover:bg-slate-750 text-slate-200 rounded text-[10px] font-semibold">
                      Inspect Trace
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Business Continuity & Disaster Recovery */}
      <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-4 text-xs">
        <h3 className="text-sm font-semibold text-slate-100 flex items-center gap-2">
          <Database className="w-4 h-4 text-cyan-400" />
          Business Continuity & Disaster Recovery Matrix
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-4 bg-slate-950 rounded-xl border border-slate-850">
            <span className="text-slate-400 block font-medium">Multi-Region Hot Standby</span>
            <span className="text-base font-bold text-emerald-400 mt-1 block">Active / Hot Standby</span>
            <p className="text-slate-400 mt-1">Secondary database cluster synced with zero replication lag across AWS eu-west-1 and af-south-1.</p>
          </div>
          <div className="p-4 bg-slate-950 rounded-xl border border-slate-850">
            <span className="text-slate-400 block font-medium">Backup Integrity (Hourly Snapshots)</span>
            <span className="text-base font-bold text-cyan-400 mt-1 block">100% Verified AES-GCM</span>
            <p className="text-slate-400 mt-1">Immutable WORM (Write Once Read Many) backups with air-gapped cold storage retention for 7 years.</p>
          </div>
          <div className="p-4 bg-slate-950 rounded-xl border border-slate-850">
            <span className="text-slate-400 block font-medium">Last DR Simulation Result</span>
            <span className="text-base font-bold text-indigo-300 mt-1 block">RTO 12.4s • RPO 0.0s</span>
            <p className="text-slate-400 mt-1">Recovery Time Objective & Recovery Point Objective verified within stringent fintech standards.</p>
          </div>
        </div>
      </div>
    </div>
  );
};
