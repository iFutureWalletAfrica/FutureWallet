import { useState } from 'react';
import { 
  ShieldCheck, 
  UserCheck, 
  FileText, 
  ShieldAlert, 
  AlertTriangle, 
  Search, 
  Eye, 
  CheckCircle2, 
  XCircle, 
  Download,
  Filter
} from 'lucide-react';
import { KYC_APPLICANTS, AML_CASES } from '../../data/mockFintechData';
import { KycApplicant, AmlCase } from '../../types';

interface CcoDashboardProps {
  onOpenKycModal: (applicant: KycApplicant) => void;
  onOpenReportExport: () => void;
}

export const CcoDashboard = ({ onOpenKycModal, onOpenReportExport }: CcoDashboardProps) => {
  const [activeTab, setActiveTab] = useState<'kyc' | 'aml' | 'regulatory'>('kyc');
  const [amlCases, setAmlCases] = useState<AmlCase[]>(AML_CASES);
  const [kycList, setKycList] = useState<KycApplicant[]>(KYC_APPLICANTS);

  const handleAmlStatusChange = (caseId: string, newStatus: any) => {
    setAmlCases((prev) =>
      prev.map((c) => (c.id === caseId ? { ...c, status: newStatus } : c))
    );
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Banner */}
      <div className="p-5 rounded-2xl bg-gradient-to-r from-slate-900 via-slate-900 to-indigo-950/40 border border-slate-800 shadow-xl flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 text-[11px] font-semibold bg-indigo-500/10 text-indigo-400 border border-indigo-500/30 rounded-full">
              CCO Compliance & AML Sentinel
            </span>
            <span className="text-xs text-slate-400">admin.ifuturewallet.com • Regulatory Seal</span>
          </div>
          <h1 className="text-xl md:text-2xl font-bold tracking-tight text-white">
            KYC/KYB Identity Verification, AML Sentinel & Central Bank Filings
          </h1>
          <p className="text-xs text-slate-400 max-w-2xl">
            Automated verification against NIBSS BVN, NIMC NIN biometric databases, sanctions screening, and suspicious transaction reports (STR/SAR).
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={onOpenReportExport}
            className="px-3.5 py-2 text-xs font-semibold bg-indigo-500 hover:bg-indigo-400 text-white rounded-lg flex items-center gap-2 shadow-lg shadow-indigo-500/10 transition-colors"
          >
            <Download className="w-4 h-4" />
            Statutory FIU Report
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-slate-800 text-xs font-medium gap-2">
        <button
          onClick={() => setActiveTab('kyc')}
          className={`pb-3 px-3 transition-colors flex items-center gap-2 border-b-2 ${
            activeTab === 'kyc'
              ? 'border-indigo-400 text-indigo-400 font-semibold'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <UserCheck className="w-4 h-4" />
          KYC / KYB Verification Queue
        </button>
        <button
          onClick={() => setActiveTab('aml')}
          className={`pb-3 px-3 transition-colors flex items-center gap-2 border-b-2 ${
            activeTab === 'aml'
              ? 'border-indigo-400 text-indigo-400 font-semibold'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <ShieldAlert className="w-4 h-4" />
          AML Monitoring & Investigation Cases
        </button>
        <button
          onClick={() => setActiveTab('regulatory')}
          className={`pb-3 px-3 transition-colors flex items-center gap-2 border-b-2 ${
            activeTab === 'regulatory'
              ? 'border-indigo-400 text-indigo-400 font-semibold'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <FileText className="w-4 h-4" />
          Regulatory Compliance Reports
        </button>
      </div>

      {/* TAB 1: KYC / KYB */}
      {activeTab === 'kyc' && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3.5">
            <div className="p-4 bg-slate-900 rounded-xl border border-slate-800">
              <span className="text-xs text-slate-400 block">Verified Users</span>
              <span className="text-xl font-bold text-emerald-400 font-mono mt-1 block">4,482,900</span>
              <span className="text-[11px] text-slate-500">Tier-1, 2, & 3 validated</span>
            </div>
            <div className="p-4 bg-slate-900 rounded-xl border border-slate-800">
              <span className="text-xs text-slate-400 block">Pending Verification</span>
              <span className="text-xl font-bold text-amber-400 font-mono mt-1 block">482</span>
              <span className="text-[11px] text-slate-500">Biometric match in progress</span>
            </div>
            <div className="p-4 bg-slate-900 rounded-xl border border-slate-800">
              <span className="text-xs text-slate-400 block">Rejected Applications</span>
              <span className="text-xl font-bold text-rose-400 font-mono mt-1 block">118</span>
              <span className="text-[11px] text-slate-500">Failed document integrity</span>
            </div>
            <div className="p-4 bg-slate-900 rounded-xl border border-slate-800">
              <span className="text-xs text-slate-400 block">High-Risk Users Flagged</span>
              <span className="text-xl font-bold text-rose-300 font-mono mt-1 block">14</span>
              <span className="text-[11px] text-rose-400">PEP / Watchlist screening</span>
            </div>
          </div>

          <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-semibold text-slate-100 flex items-center gap-2">
                <UserCheck className="w-4 h-4 text-indigo-400" />
                Active Verification Queue & Document Inspection Desk
              </h3>
              <span className="text-xs text-slate-400">Click inspect to review credentials and approve</span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-800 text-slate-400">
                    <th className="pb-3 font-medium">Applicant Name</th>
                    <th className="pb-3 font-medium">Tier Requested</th>
                    <th className="pb-3 font-medium">BVN (NIBSS)</th>
                    <th className="pb-3 font-medium">NIN (NIMC)</th>
                    <th className="pb-3 font-medium">Risk Score</th>
                    <th className="pb-3 font-medium">Submitted</th>
                    <th className="pb-3 font-medium">Status</th>
                    <th className="pb-3 font-medium text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-850">
                  {kycList.map((app) => (
                    <tr key={app.id} className="hover:bg-slate-850/40 transition-colors">
                      <td className="py-3">
                        <span className="font-semibold text-slate-200 block">{app.fullName}</span>
                        <span className="text-[11px] text-slate-500 font-mono">{app.phone}</span>
                      </td>
                      <td className="py-3 text-slate-300">{app.tierRequested}</td>
                      <td className="py-3 font-mono text-cyan-400">{app.bvn}</td>
                      <td className="py-3 font-mono text-slate-300">{app.nin}</td>
                      <td className="py-3 font-mono font-bold">
                        <span className={app.riskScore > 50 ? 'text-rose-400' : 'text-emerald-400'}>
                          {app.riskScore} / 100
                        </span>
                      </td>
                      <td className="py-3 text-slate-400">{app.submittedAt}</td>
                      <td className="py-3">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                            app.status === 'Verified'
                              ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                              : app.status === 'High-Risk Escalated'
                              ? 'bg-rose-500/10 text-rose-300 border border-rose-500/30'
                              : 'bg-amber-500/10 text-amber-300 border border-amber-500/30'
                          }`}
                        >
                          {app.status}
                        </span>
                      </td>
                      <td className="py-3 text-right">
                        <button
                          onClick={() => onOpenKycModal(app)}
                          className="px-3 py-1 bg-indigo-500/10 hover:bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 rounded text-xs font-semibold flex items-center gap-1.5 ml-auto"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          Inspect Dossier
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: AML MONITORING */}
      {activeTab === 'aml' && (
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-4 text-xs">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-semibold text-slate-100 flex items-center gap-2">
                <ShieldAlert className="w-4 h-4 text-rose-400" />
                Anti-Money Laundering (AML) Sentinel & High-Risk Case Management
              </h3>
              <p className="text-xs text-slate-400">Automatic velocity rules, large transaction thresholds (&gt;$10,000), and FIU SAR escalations</p>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400">
                  <th className="pb-3 font-medium">Case Number</th>
                  <th className="pb-3 font-medium">Subject Entity</th>
                  <th className="pb-3 font-medium">Transaction Ref</th>
                  <th className="pb-3 font-medium">Trigger Flag</th>
                  <th className="pb-3 font-medium">Amount</th>
                  <th className="pb-3 font-medium">Risk Score</th>
                  <th className="pb-3 font-medium">Status</th>
                  <th className="pb-3 font-medium text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-850">
                {amlCases.map((c) => (
                  <tr key={c.id} className="hover:bg-slate-850/40 transition-colors">
                    <td className="py-3 font-mono font-bold text-slate-200">{c.caseNumber}</td>
                    <td className="py-3 font-medium text-slate-100">{c.subjectName}</td>
                    <td className="py-3 font-mono text-cyan-400">{c.transactionRef}</td>
                    <td className="py-3">
                      <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-rose-500/10 text-rose-300 border border-rose-500/30">
                        {c.flagType}
                      </span>
                    </td>
                    <td className="py-3 font-mono font-bold text-emerald-400">${c.amount.toLocaleString()}</td>
                    <td className="py-3 font-mono text-rose-400 font-bold">{c.riskScore}/100</td>
                    <td className="py-3">
                      <span className="text-slate-300 font-medium">{c.status}</span>
                    </td>
                    <td className="py-3 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        {c.status !== 'Frozen' && (
                          <button
                            onClick={() => handleAmlStatusChange(c.id, 'Frozen')}
                            className="px-2.5 py-1 rounded bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 font-semibold"
                          >
                            Freeze Wallet
                          </button>
                        )}
                        {c.status !== 'Reported to FIU' && (
                          <button
                            onClick={() => handleAmlStatusChange(c.id, 'Reported to FIU')}
                            className="px-2.5 py-1 rounded bg-indigo-500/10 hover:bg-indigo-500/20 text-indigo-300 font-semibold"
                          >
                            SAR File
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 3: REGULATORY REPORTS */}
      {activeTab === 'regulatory' && (
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-4 text-xs">
          <h3 className="text-sm font-semibold text-slate-100 flex items-center gap-2">
            <FileText className="w-4 h-4 text-emerald-400" />
            Central Bank & Regulatory Compliance Dossiers
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 bg-slate-950 rounded-xl border border-slate-850">
              <h4 className="font-semibold text-slate-200 mb-1">Monthly AML Suspicious Activity Report (SAR)</h4>
              <p className="text-slate-400">Electronic submission to Financial Intelligence Unit with transaction audit hashes.</p>
              <div className="mt-3 flex items-center justify-between text-slate-500">
                <span>Status: Filed & Cleared</span>
                <span className="text-emerald-400 font-semibold">Sept 2026 Conformed</span>
              </div>
            </div>
            <div className="p-4 bg-slate-950 rounded-xl border border-slate-850">
              <h4 className="font-semibold text-slate-200 mb-1">CBN Capital Adequacy & Trust Account Audit</h4>
              <p className="text-slate-400">Custodial reserve verification across Zenith, Access, and 9PSB settlement accounts.</p>
              <div className="mt-3 flex items-center justify-between text-slate-500">
                <span>Ratio: 24.8%</span>
                <span className="text-emerald-400 font-semibold">Unreserved</span>
              </div>
            </div>
            <div className="p-4 bg-slate-950 rounded-xl border border-slate-850">
              <h4 className="font-semibold text-slate-200 mb-1">Partner Bank Compliance SLA Scorecard</h4>
              <p className="text-slate-400">Monthly bilateral reviews of merchant acquiring guidelines and dispute arbitration.</p>
              <div className="mt-3 flex items-center justify-between text-slate-500">
                <span>Score: 99.4%</span>
                <span className="text-emerald-400 font-semibold">Full Compliance</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
