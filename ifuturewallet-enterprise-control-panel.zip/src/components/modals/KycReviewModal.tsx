import { useState } from 'react';
import { UserCheck, ShieldAlert, CheckCircle, XCircle, FileText, Phone, CreditCard, X } from 'lucide-react';
import { KycApplicant } from '../../types';

interface KycReviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  applicant: KycApplicant | null;
  onActionComplete: (applicantId: string, newStatus: 'Verified' | 'Rejected' | 'High-Risk Escalated') => void;
}

export const KycReviewModal = ({ isOpen, onClose, applicant, onActionComplete }: KycReviewModalProps) => {
  const [notes, setNotes] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);

  if (!isOpen || !applicant) return null;

  const handleAction = (status: 'Verified' | 'Rejected' | 'High-Risk Escalated') => {
    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      onActionComplete(applicant.id, status);
      onClose();
    }, 600);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 animate-in fade-in duration-150">
      <div className="bg-slate-900 border border-slate-700 rounded-xl w-full max-w-xl overflow-hidden shadow-2xl flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-900/90">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
              <UserCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-semibold text-slate-100">KYC/KYB Verification Dossier</h3>
              <p className="text-xs text-slate-400">ID: {applicant.id} • Regulatory Identity Pipeline</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-200 p-1.5 rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-4 text-sm">
          {/* Identity Card */}
          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3">
            <div className="flex items-start justify-between">
              <div>
                <h4 className="text-base font-medium text-slate-100">{applicant.fullName}</h4>
                <p className="text-xs text-slate-400 mt-0.5">Applied for {applicant.tierRequested}</p>
              </div>
              <div className="text-right">
                <span className="text-[11px] text-slate-400 block">Risk Score</span>
                <span
                  className={`text-sm font-bold ${
                    applicant.riskScore > 50 ? 'text-rose-400' : 'text-emerald-400'
                  }`}
                >
                  {applicant.riskScore} / 100 {applicant.riskScore > 50 ? '(Elevated)' : '(Low Risk)'}
                </span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 pt-2 border-t border-slate-850 text-xs">
              <div>
                <span className="text-slate-500 block flex items-center gap-1.5 mb-1">
                  <CreditCard className="w-3.5 h-3.5" /> BVN (Bank Verification No.)
                </span>
                <span className="font-mono text-slate-200 bg-slate-900 px-2 py-1 rounded block">
                  {applicant.bvn} (NIBSS Matched)
                </span>
              </div>
              <div>
                <span className="text-slate-500 block flex items-center gap-1.5 mb-1">
                  <FileText className="w-3.5 h-3.5" /> NIN (National Identity No.)
                </span>
                <span className="font-mono text-slate-200 bg-slate-900 px-2 py-1 rounded block">
                  {applicant.nin} (NIMC Validated)
                </span>
              </div>
              <div>
                <span className="text-slate-500 block flex items-center gap-1.5 mb-1">
                  <Phone className="w-3.5 h-3.5" /> Primary Phone
                </span>
                <span className="text-slate-200">{applicant.phone}</span>
              </div>
              <div>
                <span className="text-slate-500 block flex items-center gap-1.5 mb-1">
                  <FileText className="w-3.5 h-3.5" /> Verified Document
                </span>
                <span className="text-slate-200">{applicant.documentType}</span>
              </div>
            </div>
          </div>

          {/* Review Notes */}
          <div>
            <label className="block text-xs font-medium text-slate-400 mb-1.5">Compliance Officer Notes & Justification</label>
            <textarea
              rows={3}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. Identity verified against NIBSS direct biometrics. Sanctions check negative."
              className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500"
            />
          </div>
        </div>

        {/* Action Buttons */}
        <div className="px-6 py-4 border-t border-slate-800 bg-slate-900 flex items-center justify-between">
          <button
            onClick={() => handleAction('High-Risk Escalated')}
            disabled={isProcessing}
            className="px-3 py-2 text-xs font-medium bg-amber-500/10 text-amber-300 hover:bg-amber-500/20 border border-amber-500/30 rounded-lg flex items-center gap-1.5 transition-colors disabled:opacity-50"
          >
            <ShieldAlert className="w-4 h-4" />
            Escalate to AML
          </button>
          <div className="flex items-center gap-2">
            <button
              onClick={() => handleAction('Rejected')}
              disabled={isProcessing}
              className="px-3.5 py-2 text-xs font-medium bg-rose-500/10 text-rose-300 hover:bg-rose-500/20 border border-rose-500/30 rounded-lg flex items-center gap-1.5 transition-colors disabled:opacity-50"
            >
              <XCircle className="w-4 h-4" />
              Reject Applicant
            </button>
            <button
              onClick={() => handleAction('Verified')}
              disabled={isProcessing}
              className="px-4 py-2 text-xs font-semibold bg-emerald-500 hover:bg-emerald-400 text-slate-950 rounded-lg flex items-center gap-1.5 shadow-lg shadow-emerald-500/10 transition-colors disabled:opacity-50"
            >
              <CheckCircle className="w-4 h-4" />
              Approve & Upgrade Tier
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
