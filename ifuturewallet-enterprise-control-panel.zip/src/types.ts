export type DashboardRole = 
  | 'ceo'
  | 'board'
  | 'cto'
  | 'coo'
  | 'cfo'
  | 'cco'
  | 'cro'
  | 'legal'
  | 'cmo'
  | 'growth'
  | 'partners'
  | 'ifw_coin'
  | 'security'
  | 'hr'
  | 'audit'
  | 'dpo'
  | 'settings';

export type UserRole = DashboardRole;

export interface UserPersona {
  id: string;
  name: string;
  title: string;
  role: DashboardRole;
  avatar: string;
  clearanceLevel: string;
}

export interface CeoMetrics {
  totalRegisteredUsers: number;
  activeUsers: number;
  newUsersToday: number;
  mau: number;
  transactionVolume: number;
  transactionValue: number; // in USD or equivalent
  revenueGenerated: number;
  growthRate: number; // percentage
  csatScore: number; // out of 5
  // Financial Overview
  totalWalletBalance: number;
  totalMoneyInflow: number;
  totalMoneyOutflow: number;
  settlementStatus: '100% Settled' | 'Pending Settlement' | 'Reconciling';
  partnerRevenueShare: number;
  commissionPaid: number;
  companyIncome: number;
  // Risk Overview
  fraudAlertsCount: number;
  suspiciousTxnCount: number;
  failedTxnCount: number;
  systemDowntime: string; // e.g. "99.992%"
  complianceAlertsCount: number;
  securityIncidentsCount: number;
}

export interface ExecutiveReport {
  id: string;
  title: string;
  period: 'Daily' | 'Weekly' | 'Monthly' | 'Annual';
  generatedAt: string;
  size: string;
  status: 'Ready' | 'Generating';
  highlights: string[];
  metricsSummary: {
    inflow: string;
    outflow: string;
    activeUsers: string;
    successRate: string;
  };
}

export interface BoardResolution {
  id: string;
  code: string;
  title: string;
  dateProposed: string;
  sponsor: string;
  status: 'Approved' | 'Pending Review' | 'Tabled' | 'In Execution';
  votesFor: number;
  votesAgainst: number;
  category: 'Corporate Governance' | 'Capital Allocation' | 'Tech Roadmap' | 'Regulatory';
}

export interface BoardMeeting {
  id: string;
  title: string;
  date: string;
  time: string;
  location: string;
  attendeesCount: number;
  status: 'Upcoming' | 'Completed';
  agendaItems: string[];
}

export interface ServerNode {
  id: string;
  name: string;
  region: string;
  status: 'Healthy' | 'Degraded' | 'Maintenance';
  cpuUsage: number;
  memoryUsage: number;
  latencyMs: number;
  uptime: string;
}

export interface MobileAppVersion {
  platform: 'Android' | 'iOS';
  version: string;
  adoptionRate: number;
  activeInstalls: number;
  crashFreeRate: number;
  releaseStatus: 'Live (100%)' | 'Phased Rollout (45%)' | 'Review';
  lastUpdated: string;
}

export interface DeveloperAccount {
  id: string;
  name: string;
  email: string;
  team: string;
  accessRole: 'Lead Architect' | 'Core Backend' | 'Mobile Engineer' | 'DevOps Lead';
  lastDeployment: string;
  commitsThisWeek: number;
  status: 'Active' | 'On Call';
}

export interface ApiClient {
  id: string;
  companyName: string;
  tier: 'Enterprise' | 'Growth' | 'Sandbox';
  apiKey: string;
  secretKeyMasked: string;
  env: 'Production' | 'Sandbox';
  dailyRequests: number;
  monthlyLimit: number;
  successRate: number;
  monthlyRevenue: number;
  whitelistedIps: string[];
  status: 'Active' | 'Restricted';
}

export interface ApiEndpointStat {
  product: 'Wallet API' | 'Payment API' | 'Virtual Account API' | 'KYC API';
  endpoint: string;
  method: 'POST' | 'GET';
  description: string;
  requestVolume: number;
  latencyMs: number;
  successRate: number;
}

export interface CustomerOperationMetric {
  totalCustomers: number;
  activeCustomers: number;
  suspendedAccounts: number;
  accountRecoveryRequests: number;
}

export interface ComplaintTicket {
  id: string;
  customerName: string;
  accountNumber: string;
  category: 'Transaction Dispute' | 'Failed Transfer' | 'Card Binding' | 'KYC Verification' | 'App Glitch';
  priority: 'Critical' | 'High' | 'Medium' | 'Low';
  status: 'Open' | 'Escalated' | 'Resolved';
  assignedTo: string;
  createdAt: string;
  responseTimeMin: number;
}

export interface RegionalHierarchyNode {
  regionName: string;
  regionalManager: {
    name: string;
    email: string;
    phone: string;
  };
  clusterManagers: {
    name: string;
    clusterArea: string;
    activeDevs: number;
    targetAchievement: number;
  }[];
  totalUsers: number;
  revenueGenerated: number;
  targetUsers: number;
  ranking: number;
}

export interface BusinessDeveloper {
  id: string;
  name: string;
  code: string;
  cluster: string;
  activeReferrals: number;
  newRegistrationsToday: number;
  commissionEarned: number;
  performanceTier: 'Diamond' | 'Gold' | 'Silver' | 'Bronze';
  status: 'Active' | 'Pending Review';
}

export interface BankTreasuryAccount {
  id: string;
  bankName: string;
  accountType: 'Commercial Bank' | 'Payment Service Bank (PSB)' | 'Microfinance Bank (MFB)';
  accountNumberMasked: string;
  balance: number;
  currency: string;
  settlementSpeed: string;
  status: 'Operational' | 'Settling';
}

export interface TransactionRecord {
  id: string;
  reference: string;
  type: 'Wallet Deposit' | 'Withdrawal' | 'Transfer' | 'Bill Payment' | 'Merchant Payment';
  amount: number;
  sender: string;
  recipient: string;
  timestamp: string;
  status: 'Successful' | 'Pending' | 'Flagged' | 'Failed';
  channel: 'Card' | 'Bank Transfer' | 'USSD' | 'IFW Token' | 'Virtual Account';
  fee: number;
}

export interface KycApplicant {
  id: string;
  fullName: string;
  bvn: string;
  nin: string;
  phone: string;
  tierRequested: 'Tier 1' | 'Tier 2 (Full KYB)' | 'Tier 3 (Enterprise)';
  riskScore: number; // 0 - 100
  status: 'Pending' | 'Verified' | 'Rejected' | 'High-Risk Escalated';
  submittedAt: string;
  documentType: 'Passport' | "Driver's License" | 'National Identity Slip';
}

export interface AmlCase {
  id: string;
  caseNumber: string;
  subjectName: string;
  transactionRef: string;
  flagType: 'Large Volume Velocity' | 'Sanctions List Hit' | 'Unusual Cross-Border' | 'Structurer Pattern';
  amount: number;
  riskScore: number;
  status: 'Under Investigation' | 'Frozen' | 'Cleared' | 'Reported to FIU';
  assignedAnalyst: string;
  updatedAt: string;
}

export interface FraudAlertItem {
  id: string;
  eventType: 'Brute Force Attack' | 'Multiple Device Swapping' | 'Card Velocity Surge' | 'SIM Swap Suspected';
  affectedAccount: string;
  ipAddress: string;
  location: string;
  severity: 'Critical' | 'High' | 'Medium';
  actionTaken: 'Account Auto-Frozen' | '2FA Challenged' | 'Transaction Held';
  timestamp: string;
}

export interface LegalContract {
  id: string;
  title: string;
  category: 'Bank Agreement' | 'Partner Agreement' | 'API Contract' | 'Vendor Contract' | 'Employment Contract';
  counterparty: string;
  signedDate: string;
  expiryDate: string;
  status: 'Active' | 'Reviewing Renewal' | 'Pending Sign-off';
  value: string;
}

export interface IntellectualPropertyAsset {
  id: string;
  name: string;
  type: 'Registered Trademark' | 'Software Copyright' | 'Patent Application' | 'Brand Asset';
  registrationNumber: string;
  jurisdiction: string;
  status: 'Protected' | 'Filed' | 'In Renewal';
  renewalDate: string;
}

export interface MarketingCampaign {
  id: string;
  name: string;
  channel: 'Digital / PPC' | 'Referral Drive' | 'Campus Ambassador' | 'Influencer Fintech';
  spend: number;
  newAcquisitions: number;
  cac: number;
  conversionRate: number;
  status: 'Live' | 'Scheduled' | 'Completed';
}

export interface PartnerEntity {
  id: string;
  name: string;
  category: 'Banking Partner' | 'Merchant Partner' | 'Strategic Partner';
  subCategory: 'PSB' | 'Commercial Bank' | 'MFB' | 'Retail E-commerce' | 'Supermarket Chain' | 'Cloud/Tech';
  totalVolume: number;
  settlementBalance: number;
  uptimeRate: number;
  status: 'Active' | 'Under Audit';
  contactPerson: string;
}

export interface IfwTokenomics {
  totalSupply: number; // 105,000,000 IFW
  circulatingSupply: number;
  lockedSupply: number;
  burnedTokens: number;
  treasuryHoldings: number;
  marketPriceUsd: number;
  marketCapUsd: number;
  allocations: {
    category: string;
    percentage: number;
    amount: number;
    color: string;
  }[];
  rewardMultipliers: {
    dailyLogin: number;
    transfer: number;
    referral: number;
    kycCompleted: number;
    loyaltyTier: number;
  };
}

export interface IfwStakingPool {
  id: string;
  name: string;
  durationDays: number;
  apyPercent: number;
  totalStaked: number;
  participants: number;
  status: 'Active' | 'Cap Reached';
}

export interface StaffProfile {
  id: string;
  name: string;
  department: 'Engineering' | 'Executive' | 'Operations' | 'Finance' | 'Risk & Compliance' | 'Marketing' | 'Legal';
  title: string;
  attendanceRate: number;
  performanceScore: number; // out of 100
  payrollStatus: 'Disbursed' | 'Pending Approval';
  monthlySalary: string;
}

export interface InternalAuditItem {
  id: string;
  controlCode: string;
  framework: 'PCI-DSS v4.0' | 'ISO/IEC 27001' | 'SOC 2 Type II' | 'CBN Guidelines';
  controlName: string;
  status: 'Compliant' | 'Remediation Required' | 'Tested & Verified';
  lastAudited: string;
  auditorNotes: string;
}

export interface DataPrivacyRequest {
  id: string;
  applicantName: string;
  requestType: 'Right to Access' | 'Right to be Forgotten' | 'Data Portability' | 'Consent Revocation';
  submissionDate: string;
  deadlineDate: string;
  status: 'Completed' | 'Processing' | 'Verified Identity';
  dpoDecision: 'Granted' | 'Pending Analysis';
}

export interface EcosystemPartner {
  id: string;
  name: string;
  category: string;
  integrationType: string;
  volumeMonth: number;
  commissionRate: string;
  outstandingBalance: number;
  settlementStatus: 'Settled' | 'Pending Clearing';
}

export interface TokenBurnEvent {
  id: string;
  txHash: string;
  amount: number;
  usdValue: number;
  burnedAt: string;
  quarter: string;
}

export interface SecurityAuditLog {
  id: string;
  operator: string;
  action: string;
  subsystem: string;
  ipAddress: string;
  severity: 'High' | 'Medium' | 'Low';
  timestamp: string;
}

export interface EmployeeRecord {
  id: string;
  name: string;
  department: string;
  role: string;
  walletAddress: string;
  salary: number;
  workMode: 'On-site' | 'Remote' | 'Hybrid';
  status: 'Active on Duty' | 'On Leave';
}

export interface PlatformFeeConfig {
  depositFeePercent: number;
  withdrawalFeePercent: number;
  p2pTransferFeePercent: number;
  billPaymentCommissionPercent: number;
  merchantMdrPercent: number;
  ifwCoinDiscountPercent: number;
}

export interface CurrencyConfig {
  code: string;
  name: string;
  symbol: string;
  exchangeRateToUsd: number;
  enabled: boolean;
}

