import {
  UserPersona,
  CeoMetrics,
  ExecutiveReport,
  BoardResolution,
  BoardMeeting,
  ServerNode,
  MobileAppVersion,
  DeveloperAccount,
  ApiClient,
  ApiEndpointStat,
  ComplaintTicket,
  RegionalHierarchyNode,
  BusinessDeveloper,
  BankTreasuryAccount,
  TransactionRecord,
  KycApplicant,
  AmlCase,
  FraudAlertItem,
  LegalContract,
  IntellectualPropertyAsset,
  MarketingCampaign,
  PartnerEntity,
  IfwTokenomics,
  IfwStakingPool,
  StaffProfile,
  InternalAuditItem,
  DataPrivacyRequest,
  EcosystemPartner,
  TokenBurnEvent,
  SecurityAuditLog,
  EmployeeRecord,
  PlatformFeeConfig,
  CurrencyConfig,
} from '../types';

export const USER_PERSONAS: UserPersona[] = [
  {
    id: 'ceo',
    name: 'Dr. Marcus Vance, Ph.D.',
    title: 'Chief Executive Officer (CEO)',
    role: 'ceo',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    clearanceLevel: 'Executive Level 5 (Root)',
  },
  {
    id: 'board',
    name: 'Dame Eleanor Sterling',
    title: 'Chairperson, Board Governance',
    role: 'board',
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80',
    clearanceLevel: 'Board Trustee (Level 5)',
  },
  {
    id: 'cto',
    name: 'Engr. Tariq Al-Mansoor',
    title: 'Chief Technology Officer (CTO)',
    role: 'cto',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    clearanceLevel: 'SysOps SuperAdmin (Level 4)',
  },
  {
    id: 'coo',
    name: 'Amina Bello-Kalu',
    title: 'Chief Operating Officer (COO)',
    role: 'coo',
    avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=150&auto=format&fit=crop&q=80',
    clearanceLevel: 'Ops Command (Level 4)',
  },
  {
    id: 'cfo',
    name: 'Henrik Lindqvist',
    title: 'Chief Financial Officer (CFO)',
    role: 'cfo',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
    clearanceLevel: 'Treasury Controller (Level 4)',
  },
  {
    id: 'cco',
    name: 'Barrister Folake Adeleke',
    title: 'Chief Compliance Officer (CCO)',
    role: 'cco',
    avatar: 'https://images.unsplash.com/photo-1567532939604-b6b5b0db2604?w=150&auto=format&fit=crop&q=80',
    clearanceLevel: 'Regulatory Seal (Level 4)',
  },
  {
    id: 'cro',
    name: 'Viktor Zimmerman',
    title: 'Chief Risk Officer (CRO)',
    role: 'cro',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&auto=format&fit=crop&q=80',
    clearanceLevel: 'Risk & Fraud Matrix (Level 4)',
  },
  {
    id: 'ifw_coin',
    name: 'Sora Takahashi',
    title: 'VP of IFW Tokenomics & Web3',
    role: 'ifw_coin',
    avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150&auto=format&fit=crop&q=80',
    clearanceLevel: 'Smart Contract Keyholder',
  },
  {
    id: 'partners',
    name: 'Chinedu Eze',
    title: 'Chief Partnership Officer',
    role: 'partners',
    avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=150&auto=format&fit=crop&q=80',
    clearanceLevel: 'Alliance Manager (Level 4)',
  },
  {
    id: 'audit',
    name: 'Claire Moreau',
    title: 'Head of Internal Audit',
    role: 'audit',
    avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&auto=format&fit=crop&q=80',
    clearanceLevel: 'Independent Auditor (Level 4)',
  },
  {
    id: 'dpo',
    name: 'Kwame Mensah, CIPP/E',
    title: 'Data Protection Officer (DPO)',
    role: 'dpo',
    avatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=150&auto=format&fit=crop&q=80',
    clearanceLevel: 'Privacy & GDPR Steward',
  },
];

export const INITIAL_CEO_METRICS: CeoMetrics = {
  totalRegisteredUsers: 4829340,
  activeUsers: 3418920,
  newUsersToday: 18450,
  mau: 3942000,
  transactionVolume: 14829100, // count
  transactionValue: 842500000, // $842.5M
  revenueGenerated: 42180000, // $42.18M
  growthRate: 28.4,
  csatScore: 4.86,
  // Financial Overview
  totalWalletBalance: 612400000,
  totalMoneyInflow: 289400000,
  totalMoneyOutflow: 247220000,
  settlementStatus: '100% Settled',
  partnerRevenueShare: 8940000,
  commissionPaid: 3420000,
  companyIncome: 29820000,
  // Risk Overview
  fraudAlertsCount: 14,
  suspiciousTxnCount: 29,
  failedTxnCount: 142,
  systemDowntime: '99.994%',
  complianceAlertsCount: 7,
  securityIncidentsCount: 0,
};

export const EXECUTIVE_REPORTS: ExecutiveReport[] = [
  {
    id: 'rep-01',
    title: 'Q3 Enterprise Performance & Treasury Audit',
    period: 'Monthly',
    generatedAt: 'Today at 06:00 UTC',
    size: '18.4 MB (Encrypted PDF)',
    status: 'Ready',
    highlights: [
      'Record high daily inflow: $14.2M processed via commercial bank clearing.',
      'MAU surpassed 3.94M with zero critical gateway downtime incidents.',
      'IFW Coin allocation unlocked milestone #4 executed according to schedule.',
    ],
    metricsSummary: {
      inflow: '$289.4M',
      outflow: '$247.2M',
      activeUsers: '3.42M',
      successRate: '99.88%',
    },
  },
  {
    id: 'rep-02',
    title: 'Weekly Cross-Border & Settlement Reconciliation',
    period: 'Weekly',
    generatedAt: 'Yesterday 23:59 UTC',
    size: '12.1 MB (XLSX + Signed PDF)',
    status: 'Ready',
    highlights: [
      'Instant settlement pipeline achieved 100% clearing across all 8 partner banks.',
      'Chargeback ratio reduced to 0.008%, best in regional benchmark.',
    ],
    metricsSummary: {
      inflow: '$74.1M',
      outflow: '$63.5M',
      activeUsers: '2.81M',
      successRate: '99.94%',
    },
  },
  {
    id: 'rep-03',
    title: 'Daily High-Frequency Operations & AML Log',
    period: 'Daily',
    generatedAt: '01:00 UTC Today',
    size: '4.8 MB (PDF)',
    status: 'Ready',
    highlights: [
      '18,450 new KYC Tier-1 onboardings with zero downtime.',
      'AML sentinel flagged 4 suspicious structuring attempts - accounts frozen automatically.',
    ],
    metricsSummary: {
      inflow: '$18.9M',
      outflow: '$16.2M',
      activeUsers: '1.24M',
      successRate: '99.91%',
    },
  },
  {
    id: 'rep-04',
    title: 'FY2025-2026 Comprehensive Board Investor Dossier',
    period: 'Annual',
    generatedAt: 'Sep 15, 2026',
    size: '42.6 MB (Board Verified)',
    status: 'Ready',
    highlights: [
      '142% Year-over-Year revenue expansion in API & Virtual Account products.',
      'Clean unreserved audit opinion issued by PwC Internal Audit team.',
    ],
    metricsSummary: {
      inflow: '$2.84B',
      outflow: '$2.41B',
      activeUsers: '4.82M',
      successRate: '99.92%',
    },
  },
];

export const BOARD_RESOLUTIONS: BoardResolution[] = [
  {
    id: 'res-801',
    code: 'RES-2026-089',
    title: 'Authorization of IFW Ecosystem Reserve Expansion & Tier-1 Liquidity Pools',
    dateProposed: 'Sep 12, 2026',
    sponsor: 'Dame Eleanor Sterling',
    status: 'Approved',
    votesFor: 9,
    votesAgainst: 0,
    category: 'Capital Allocation',
  },
  {
    id: 'res-802',
    code: 'RES-2026-090',
    title: 'Ratification of Commercial Banking API Whitelist Partnership Agreements',
    dateProposed: 'Sep 05, 2026',
    sponsor: 'Dr. Marcus Vance',
    status: 'In Execution',
    votesFor: 8,
    votesAgainst: 1,
    category: 'Corporate Governance',
  },
  {
    id: 'res-803',
    code: 'RES-2026-091',
    title: 'Adoption of Enhanced ISO 27001 / PCI-DSS v4.0 Zero-Trust Cloud Architecture',
    dateProposed: 'Aug 28, 2026',
    sponsor: 'Engr. Tariq Al-Mansoor',
    status: 'Approved',
    votesFor: 9,
    votesAgainst: 0,
    category: 'Tech Roadmap',
  },
  {
    id: 'res-804',
    code: 'RES-2026-092',
    title: 'Expansion of North West Regional Operations & 500 Cluster Agent Subsidies',
    dateProposed: 'Aug 14, 2026',
    sponsor: 'Amina Bello-Kalu',
    status: 'Approved',
    votesFor: 7,
    votesAgainst: 2,
    category: 'Regulatory',
  },
];

export const BOARD_MEETINGS: BoardMeeting[] = [
  {
    id: 'bm-01',
    title: 'Q3 Board of Directors Ordinary General Assembly',
    date: 'Sep 26, 2026',
    time: '14:00 - 17:30 UTC',
    location: 'Executive Boardroom, Floor 42 & Encrypted Video Link',
    attendeesCount: 11,
    status: 'Upcoming',
    agendaItems: [
      'CEO State of the Enterprise Address & H2 Projections',
      'Audit Committee Review: AML & Risk Matrix',
      'IFW Coin Staking Pool Cap Adjustments & Treasury Lockup Review',
      'Global License Filings in Sub-Saharan & Middle East Jurisdictions',
    ],
  },
  {
    id: 'bm-02',
    title: 'Technology & Risk Oversight Committee Emergency Briefing',
    date: 'Sep 08, 2026',
    time: '10:00 - 11:45 UTC',
    location: 'Hybrid Encrypted Portal',
    attendeesCount: 8,
    status: 'Completed',
    agendaItems: [
      'Core Switch 3.4.0 Latency Reduction Verification',
      'Disaster Recovery Drill Failover Testing Results (12.4s recovery)',
      'Review of Central Bank Compliance Directives',
    ],
  },
];

export const SERVER_NODES: ServerNode[] = [
  { id: 'node-01', name: 'core-switch-prod-01', region: 'eu-west-1 (Primary)', status: 'Healthy', cpuUsage: 24, memoryUsage: 58, latencyMs: 12, uptime: '99.998%' },
  { id: 'node-02', name: 'core-switch-prod-02', region: 'eu-west-1 (Secondary)', status: 'Healthy', cpuUsage: 22, memoryUsage: 54, latencyMs: 14, uptime: '99.999%' },
  { id: 'node-03', name: 'settlement-db-cluster-master', region: 'eu-central-1', status: 'Healthy', cpuUsage: 41, memoryUsage: 72, latencyMs: 18, uptime: '100%' },
  { id: 'node-04', name: 'api-gateway-edge-lagos', region: 'af-south-1', status: 'Healthy', cpuUsage: 35, memoryUsage: 61, latencyMs: 8, uptime: '99.995%' },
  { id: 'node-05', name: 'ifw-blockchain-validator-01', region: 'global-node-pool', status: 'Healthy', cpuUsage: 19, memoryUsage: 44, latencyMs: 22, uptime: '100%' },
  { id: 'node-06', name: 'kyc-biometric-pipeline-worker', region: 'eu-west-1', status: 'Healthy', cpuUsage: 52, memoryUsage: 68, latencyMs: 28, uptime: '99.992%' },
];

export const MOBILE_APPS: MobileAppVersion[] = [
  {
    platform: 'Android',
    version: 'v4.18.2 (Build 41820)',
    adoptionRate: 88.4,
    activeInstalls: 3410000,
    crashFreeRate: 99.94,
    releaseStatus: 'Live (100%)',
    lastUpdated: 'Sep 14, 2026',
  },
  {
    platform: 'iOS',
    version: 'v4.18.1 (Build 41819)',
    adoptionRate: 92.1,
    activeInstalls: 1419340,
    crashFreeRate: 99.98,
    releaseStatus: 'Live (100%)',
    lastUpdated: 'Sep 12, 2026',
  },
];

export const DEVELOPERS_LIST: DeveloperAccount[] = [
  { id: 'dev-01', name: 'Zack Chen', email: 'z.chen@ifuturewallet.com', team: 'Core Banking Protocol', accessRole: 'Lead Architect', lastDeployment: 'Today, 04:12 UTC', commitsThisWeek: 42, status: 'Active' },
  { id: 'dev-02', name: 'Fatima Sanusi', email: 'f.sanusi@ifuturewallet.com', team: 'Settlement & Switch', accessRole: 'Core Backend', lastDeployment: 'Yesterday, 19:30 UTC', commitsThisWeek: 31, status: 'Active' },
  { id: 'dev-03', name: 'Lucas Rossi', email: 'l.rossi@ifuturewallet.com', team: 'DevOps & SRE', accessRole: 'DevOps Lead', lastDeployment: '2 days ago', commitsThisWeek: 28, status: 'On Call' },
  { id: 'dev-04', name: 'Nkechi Okafor', email: 'n.okafor@ifuturewallet.com', team: 'Mobile Flutter & Swift', accessRole: 'Mobile Engineer', lastDeployment: 'Sep 14, 2026', commitsThisWeek: 37, status: 'Active' },
];

export const API_CLIENTS: ApiClient[] = [
  {
    id: 'client-01',
    companyName: 'Apex Microfinance Bank Ltd',
    tier: 'Enterprise',
    apiKey: 'ifw_live_pk_9942a98f71c4482',
    secretKeyMasked: 'ifw_live_sk_••••••••••••••••b819',
    env: 'Production',
    dailyRequests: 2420000,
    monthlyLimit: 100000000,
    successRate: 99.96,
    monthlyRevenue: 184500,
    whitelistedIps: ['197.210.64.12', '197.210.64.15', '41.203.77.2'],
    status: 'Active',
  },
  {
    id: 'client-02',
    companyName: 'OmniPay Global Commerce',
    tier: 'Enterprise',
    apiKey: 'ifw_live_pk_3301ff826b17409',
    secretKeyMasked: 'ifw_live_sk_••••••••••••••••f902',
    env: 'Production',
    dailyRequests: 1890000,
    monthlyLimit: 75000000,
    successRate: 99.91,
    monthlyRevenue: 142000,
    whitelistedIps: ['102.89.34.18', '102.89.34.22'],
    status: 'Active',
  },
  {
    id: 'client-03',
    companyName: 'KwikTransit Logistics Pay',
    tier: 'Growth',
    apiKey: 'ifw_live_pk_7718cc9032fa112',
    secretKeyMasked: 'ifw_live_sk_••••••••••••••••aa44',
    env: 'Production',
    dailyRequests: 450000,
    monthlyLimit: 20000000,
    successRate: 99.84,
    monthlyRevenue: 48500,
    whitelistedIps: ['154.120.88.9'],
    status: 'Active',
  },
  {
    id: 'client-04',
    companyName: 'FinNova Labs Sandbox Integrator',
    tier: 'Sandbox',
    apiKey: 'ifw_test_pk_001889ab8419efc',
    secretKeyMasked: 'ifw_test_sk_••••••••••••••••3311',
    env: 'Sandbox',
    dailyRequests: 12400,
    monthlyLimit: 500000,
    successRate: 98.4,
    monthlyRevenue: 0,
    whitelistedIps: ['0.0.0.0/0'],
    status: 'Active',
  },
];

export const API_ENDPOINTS: ApiEndpointStat[] = [
  { product: 'Wallet API', endpoint: '/v1/wallet/create', method: 'POST', description: 'Instant programmatic wallet generation with Tier-1 limits', requestVolume: 642000, latencyMs: 42, successRate: 99.98 },
  { product: 'Wallet API', endpoint: '/v1/wallet/balance', method: 'GET', description: 'Real-time multi-currency ledger balance query', requestVolume: 4210000, latencyMs: 16, successRate: 99.99 },
  { product: 'Wallet API', endpoint: '/v1/wallet/transfer', method: 'POST', description: 'Sub-second internal & intra-bank wallet disbursements', requestVolume: 1890000, latencyMs: 84, successRate: 99.92 },
  { product: 'Payment API', endpoint: '/v1/payments/process', method: 'POST', description: 'Acquiring gateway charge with card/USSD/transfer failover', requestVolume: 3200000, latencyMs: 110, successRate: 99.89 },
  { product: 'Payment API', endpoint: '/v1/payments/verify', method: 'GET', description: 'Instant cryptographic confirmation of settlement status', requestVolume: 2950000, latencyMs: 24, successRate: 99.97 },
  { product: 'Virtual Account API', endpoint: '/v1/virtual-accounts/create', method: 'POST', description: 'Dedicated static/dynamic virtual NUBAN generator', requestVolume: 890000, latencyMs: 65, successRate: 99.94 },
  { product: 'Virtual Account API', endpoint: '/v1/virtual-accounts/statement', method: 'GET', description: 'Audit-ready transaction history and settlement breakdown', requestVolume: 410000, latencyMs: 95, successRate: 99.90 },
  { product: 'KYC API', endpoint: '/v1/kyc/bvn-verify', method: 'POST', description: 'Direct NIBSS biometric & identity verification endpoint', requestVolume: 240000, latencyMs: 180, successRate: 99.81 },
  { product: 'KYC API', endpoint: '/v1/kyc/nin-verify', method: 'POST', description: 'NIMC National Identification Number lookup & facial match', requestVolume: 215000, latencyMs: 195, successRate: 99.78 },
];

export const COMPLAINT_TICKETS: ComplaintTicket[] = [
  { id: 'TKT-8901', customerName: 'Ibrahim Danjuma', accountNumber: '0812***481', category: 'Failed Transfer', priority: 'Critical', status: 'Open', assignedTo: 'Grace O.', createdAt: '14 mins ago', responseTimeMin: 6 },
  { id: 'TKT-8902', customerName: 'Chiamaka Eze', accountNumber: '0903***119', category: 'Transaction Dispute', priority: 'High', status: 'Escalated', assignedTo: 'Bode K.', createdAt: '42 mins ago', responseTimeMin: 12 },
  { id: 'TKT-8903', customerName: 'Adewale Adeleke', accountNumber: '0802***904', category: 'KYC Verification', priority: 'Medium', status: 'Resolved', assignedTo: 'Sandra U.', createdAt: '1 hour ago', responseTimeMin: 8 },
  { id: 'TKT-8904', customerName: 'Kano Textiles Enterprise', accountNumber: '0701***552', category: 'Card Binding', priority: 'Low', status: 'Resolved', assignedTo: 'Grace O.', createdAt: '3 hours ago', responseTimeMin: 15 },
  { id: 'TKT-8905', customerName: 'Maryam Usman', accountNumber: '0809***331', category: 'App Glitch', priority: 'High', status: 'Open', assignedTo: 'Lucas R.', createdAt: '25 mins ago', responseTimeMin: 9 },
];

export const REGIONAL_HIERARCHY_DATA: RegionalHierarchyNode = {
  regionName: 'North West Region',
  regionalManager: {
    name: 'Alhaji Mansur Garba',
    email: 'm.garba@ifuturewallet.com',
    phone: '+234 803 555 0192',
  },
  clusterManagers: [
    { name: 'Nasiru Kano', clusterArea: 'Kano Metro & Commercial Hub', activeDevs: 142, targetAchievement: 114.2 },
    { name: 'Aisha Kaduna', clusterArea: 'Kaduna Central & Industrial Zone', activeDevs: 98, targetAchievement: 106.8 },
    { name: 'Suleiman Sokoto', clusterArea: 'Sokoto & Zamfara Agricultural Basin', activeDevs: 64, targetAchievement: 98.4 },
    { name: 'Faruk Katsina', clusterArea: 'Katsina Border Trade Corridor', activeDevs: 58, targetAchievement: 102.1 },
  ],
  totalUsers: 1420800,
  revenueGenerated: 12840000,
  targetUsers: 1350000,
  ranking: 1, // #1 in the nationwide zones
};

export const BUSINESS_DEVELOPERS: BusinessDeveloper[] = [
  { id: 'bd-101', name: 'Mustapha Abdullahi', code: 'IFW-NW-001', cluster: 'Kano Metro', activeReferrals: 1840, newRegistrationsToday: 42, commissionEarned: 14200, performanceTier: 'Diamond', status: 'Active' },
  { id: 'bd-102', name: 'Zainab Ahmed', code: 'IFW-NW-044', cluster: 'Kaduna Central', activeReferrals: 1410, newRegistrationsToday: 31, commissionEarned: 10850, performanceTier: 'Diamond', status: 'Active' },
  { id: 'bd-103', name: 'Shehu Aliyu', code: 'IFW-NW-089', cluster: 'Katsina Border', activeReferrals: 980, newRegistrationsToday: 19, commissionEarned: 7420, performanceTier: 'Gold', status: 'Active' },
  { id: 'bd-104', name: 'Balarabe Bello', code: 'IFW-NW-112', cluster: 'Sokoto Basin', activeReferrals: 820, newRegistrationsToday: 14, commissionEarned: 5900, performanceTier: 'Silver', status: 'Active' },
  { id: 'bd-105', name: 'Halima Yusuf', code: 'IFW-NW-155', cluster: 'Kano Metro', activeReferrals: 690, newRegistrationsToday: 23, commissionEarned: 5200, performanceTier: 'Silver', status: 'Active' },
];

export const BANK_TREASURY_ACCOUNTS: BankTreasuryAccount[] = [
  { id: 'bank-01', bankName: 'Zenith Commercial Bank PLC', accountType: 'Commercial Bank', accountNumberMasked: '1012****89', balance: 248900000, currency: 'USD Eq.', settlementSpeed: 'Real-time (NIP/ACH)', status: 'Operational' },
  { id: 'bank-02', bankName: 'Access Commercial Bank', accountType: 'Commercial Bank', accountNumberMasked: '0048****12', balance: 182400000, currency: 'USD Eq.', settlementSpeed: 'Real-time', status: 'Operational' },
  { id: 'bank-03', bankName: '9PSB Payment Service Bank', accountType: 'Payment Service Bank (PSB)', accountNumberMasked: '9901****34', balance: 84200000, currency: 'USD Eq.', settlementSpeed: 'Instant API Netting', status: 'Settling' },
  { id: 'bank-04', bankName: 'Providus Innovation Bank', accountType: 'Commercial Bank', accountNumberMasked: '5400****90', balance: 65100000, currency: 'USD Eq.', settlementSpeed: 'Dynamic Virtual Accounts', status: 'Operational' },
  { id: 'bank-05', bankName: 'Lapomax Microfinance Bank', accountType: 'Microfinance Bank (MFB)', accountNumberMasked: '2210****67', balance: 31800000, currency: 'USD Eq.', settlementSpeed: 'Daily Batched T+0', status: 'Operational' },
];

export const RECENT_TRANSACTIONS: TransactionRecord[] = [
  { id: 'tx-901', reference: 'IFW-TXN-2026-99014', type: 'Wallet Deposit', amount: 4500, sender: 'Bayo O.', recipient: 'Main Wallet #9901', timestamp: '2 mins ago', status: 'Successful', channel: 'Bank Transfer', fee: 15 },
  { id: 'tx-902', reference: 'IFW-TXN-2026-99015', type: 'Merchant Payment', amount: 18200, sender: 'Hassan K.', recipient: 'Kano Mega Stores', timestamp: '5 mins ago', status: 'Successful', channel: 'Virtual Account', fee: 91 },
  { id: 'tx-903', reference: 'IFW-TXN-2026-99016', type: 'Transfer', amount: 89000, sender: 'Corporate Tier-3', recipient: 'External IBAN', timestamp: '8 mins ago', status: 'Flagged', channel: 'Bank Transfer', fee: 240 },
  { id: 'tx-904', reference: 'IFW-TXN-2026-99017', type: 'Bill Payment', amount: 320, sender: 'Mary J.', recipient: 'Eko Electricity (EKEDC)', timestamp: '11 mins ago', status: 'Successful', channel: 'Card', fee: 2.5 },
  { id: 'tx-905', reference: 'IFW-TXN-2026-99018', type: 'Withdrawal', amount: 15000, sender: 'Agent Point NW', recipient: 'Zenith Payout NIP', timestamp: '14 mins ago', status: 'Successful', channel: 'Bank Transfer', fee: 35 },
  { id: 'tx-906', reference: 'IFW-TXN-2026-99019', type: 'Transfer', amount: 1200, sender: 'Aliyu M.', recipient: 'IFW Stake Vault', timestamp: '18 mins ago', status: 'Successful', channel: 'IFW Token', fee: 0 },
];

export const KYC_APPLICANTS: KycApplicant[] = [
  { id: 'kyc-01', fullName: 'Emeka Chukwudi Obi', bvn: '22194830192', nin: '84920194821', phone: '+234 814 990 1201', tierRequested: 'Tier 2 (Full KYB)', riskScore: 12, status: 'Pending', submittedAt: '22 mins ago', documentType: 'National Identity Slip' },
  { id: 'kyc-02', fullName: 'Fatima Zahra Mohammed', bvn: '22401928471', nin: '77401928374', phone: '+234 803 441 8920', tierRequested: 'Tier 3 (Enterprise)', riskScore: 8, status: 'Verified', submittedAt: '1 hour ago', documentType: 'Passport' },
  { id: 'kyc-03', fullName: 'Apex Logistics Global Ltd', bvn: '22998811223', nin: '66102938471', phone: '+234 701 882 9901', tierRequested: 'Tier 2 (Full KYB)', riskScore: 86, status: 'High-Risk Escalated', submittedAt: '2 hours ago', documentType: 'Passport' },
  { id: 'kyc-04', fullName: 'Oluwaseun Adeyemi', bvn: '22019283746', nin: '55102938492', phone: '+234 809 112 3344', tierRequested: 'Tier 1', riskScore: 15, status: 'Pending', submittedAt: '3 hours ago', documentType: "Driver's License" },
];

export const AML_CASES: AmlCase[] = [
  { id: 'aml-01', caseNumber: 'AML-2026-081', subjectName: 'Apex Logistics Global Ltd', transactionRef: 'IFW-TXN-2026-99016', flagType: 'Large Volume Velocity', amount: 89000, riskScore: 86, status: 'Under Investigation', assignedAnalyst: 'Barrister Folake', updatedAt: '8 mins ago' },
  { id: 'aml-02', caseNumber: 'AML-2026-079', subjectName: 'Unknown Off-Shore Wallet #778', transactionRef: 'IFW-TXN-2026-98112', flagType: 'Sanctions List Hit', amount: 240000, riskScore: 94, status: 'Frozen', assignedAnalyst: 'Barrister Folake', updatedAt: '4 hours ago' },
  { id: 'aml-03', caseNumber: 'AML-2026-074', subjectName: 'Kano Wholesale Import Syndicate', transactionRef: 'IFW-TXN-2026-97441', flagType: 'Structurer Pattern', amount: 49500, riskScore: 78, status: 'Reported to FIU', assignedAnalyst: 'Lead Investigator T.', updatedAt: 'Yesterday' },
];

export const FRAUD_ALERTS: FraudAlertItem[] = [
  { id: 'fa-01', eventType: 'Multiple Device Swapping', affectedAccount: 'USR-884910 (K. Adams)', ipAddress: '102.89.24.11', location: 'Lagos, Nigeria', severity: 'High', actionTaken: '2FA Challenged', timestamp: '12 mins ago' },
  { id: 'fa-02', eventType: 'Card Velocity Surge', affectedAccount: 'USR-901844 (Anonymous Card)', ipAddress: '185.220.101.5', location: 'Amsterdam, NL (VPN)', severity: 'Critical', actionTaken: 'Account Auto-Frozen', timestamp: '34 mins ago' },
  { id: 'fa-03', eventType: 'SIM Swap Suspected', affectedAccount: 'USR-771920 (M. Bello)', ipAddress: '197.210.8.94', location: 'Kano, Nigeria', severity: 'Medium', actionTaken: 'Transaction Held', timestamp: '1 hour ago' },
];

export const LEGAL_CONTRACTS: LegalContract[] = [
  { id: 'con-01', title: 'Master Banking Rails SLA Agreement', category: 'Bank Agreement', counterparty: 'Zenith Commercial Bank PLC', signedDate: 'Jan 15, 2025', expiryDate: 'Jan 15, 2028', status: 'Active', value: '$12.5M / yr' },
  { id: 'con-02', title: 'Payment Service Provider Gateway Deed', category: 'Bank Agreement', counterparty: '9PSB Payment Service Bank', signedDate: 'Mar 10, 2025', expiryDate: 'Mar 10, 2027', status: 'Active', value: '$8.2M / yr' },
  { id: 'con-03', title: 'Enterprise Merchant Acquiring Partnership', category: 'Partner Agreement', counterparty: 'ShopRite Pan-Africa Group', signedDate: 'Jun 01, 2025', expiryDate: 'Jun 01, 2027', status: 'Active', value: '$4.1M / yr' },
  { id: 'con-04', title: 'Core Cloud Infrastructure Enterprise Terms', category: 'Vendor Contract', counterparty: 'Amazon Web Services (AWS)', signedDate: 'Dec 01, 2024', expiryDate: 'Dec 01, 2027', status: 'Active', value: '$2.8M / yr' },
  { id: 'con-05', title: 'Executive & Developer Intellectual Property Deeds', category: 'Employment Contract', counterparty: 'iFutureWallet Core Staff (All)', signedDate: 'Rolling', expiryDate: 'Indefinite', status: 'Active', value: 'Proprietary' },
];

export const IP_ASSETS: IntellectualPropertyAsset[] = [
  { id: 'ip-01', name: 'iFutureWallet™ Wordmark & Logo', type: 'Registered Trademark', registrationNumber: 'TM-NG-2024-884912', jurisdiction: 'Nigeria, WIPO, Madrid System', status: 'Protected', renewalDate: '2034-11-12' },
  { id: 'ip-02', name: 'IFW Coin™ Cryptocurrency & Token Branding', type: 'Registered Trademark', registrationNumber: 'TM-GLOBAL-99014', jurisdiction: 'Global WIPO Protocol', status: 'Protected', renewalDate: '2035-03-01' },
  { id: 'ip-03', name: 'iFutureWallet Core Switch & Settlement Engine v4', type: 'Software Copyright', registrationNumber: 'CR-SOFT-2025-441', jurisdiction: 'Global Bern Convention', status: 'Protected', renewalDate: 'Perpetual' },
  { id: 'ip-04', name: 'Sub-second Virtual Account Multi-hop Routing Method', type: 'Patent Application', registrationNumber: 'PAT-PEND-2025-091', jurisdiction: 'USPTO & Regional Patent Office', status: 'Filed', renewalDate: '2045-08-19' },
];

export const MARKETING_CAMPAIGNS: MarketingCampaign[] = [
  { id: 'cmp-01', name: 'North West Cashless Campus Drive', channel: 'Campus Ambassador', spend: 45000, newAcquisitions: 68400, cac: 0.65, conversionRate: 64.2, status: 'Live' },
  { id: 'cmp-02', name: 'Merchant QR Zero-Fee Onboarding Month', channel: 'Digital / PPC', spend: 85000, newAcquisitions: 112000, cac: 0.75, conversionRate: 48.9, status: 'Live' },
  { id: 'cmp-03', name: 'IFW Coin Token Utility Staking Rewards Blitz', channel: 'Influencer Fintech', spend: 60000, newAcquisitions: 94500, cac: 0.63, conversionRate: 72.1, status: 'Live' },
];

export const PARTNER_ENTITIES: PartnerEntity[] = [
  { id: 'p-01', name: 'Zenith Commercial Bank PLC', category: 'Banking Partner', subCategory: 'Commercial Bank', totalVolume: 384000000, settlementBalance: 12400000, uptimeRate: 99.98, status: 'Active', contactPerson: 'Adaeze Nwosu (VP Institutional)' },
  { id: 'p-02', name: '9PSB Payment Service Bank', category: 'Banking Partner', subCategory: 'PSB', totalVolume: 142000000, settlementBalance: 4800000, uptimeRate: 99.94, status: 'Active', contactPerson: 'Olu Martins (Head Fintech)' },
  { id: 'p-03', name: 'Lapomax Microfinance Bank', category: 'Banking Partner', subCategory: 'MFB', totalVolume: 48500000, settlementBalance: 1450000, uptimeRate: 99.89, status: 'Active', contactPerson: 'Usman Garba (COO)' },
  { id: 'p-04', name: 'ShopRite Superstores Retail', category: 'Merchant Partner', subCategory: 'Supermarket Chain', totalVolume: 74200000, settlementBalance: 2100000, uptimeRate: 100, status: 'Active', contactPerson: 'Klaus Meyer (Treasury Director)' },
  { id: 'p-05', name: 'Jumia E-Commerce Group', category: 'Merchant Partner', subCategory: 'Retail E-commerce', totalVolume: 92400000, settlementBalance: 3200000, uptimeRate: 99.97, status: 'Active', contactPerson: 'Sarah Ben-Ali (Fintech Integrations)' },
  { id: 'p-06', name: 'Mastercard Cross-Border Network', category: 'Strategic Partner', subCategory: 'Cloud/Tech', totalVolume: 210000000, settlementBalance: 8900000, uptimeRate: 99.99, status: 'Active', contactPerson: 'David Miller (Alliance Director)' },
];

export const IFW_TOKENOMICS_DATA: IfwTokenomics = {
  totalSupply: 105000000, // 105 Million IFW exact
  circulatingSupply: 42800000,
  lockedSupply: 54200000,
  burnedTokens: 8000000,
  treasuryHoldings: 32500000,
  marketPriceUsd: 1.48,
  marketCapUsd: 155400000,
  allocations: [
    { category: 'Community & Rewards', percentage: 30, amount: 31500000, color: '#10B981' }, // Emerald
    { category: 'Ecosystem', percentage: 25, amount: 26250000, color: '#06B6D4' }, // Cyan
    { category: 'Investors', percentage: 15, amount: 15750000, color: '#3B82F6' }, // Blue
    { category: 'Team', percentage: 10, amount: 10500000, color: '#8B5CF6' }, // Violet
    { category: 'Liquidity', percentage: 10, amount: 10500000, color: '#F59E0B' }, // Amber
    { category: 'Partnership', percentage: 10, amount: 10500000, color: '#EC4899' }, // Pink
  ],
  rewardMultipliers: {
    dailyLogin: 2.5, // IFW per day
    transfer: 1.0, // IFW per eligible transfer
    referral: 25.0, // IFW per KYC approved referral
    kycCompleted: 50.0, // IFW for full tier-2 completion
    loyaltyTier: 15.0, // Monthly bonus
  },
};

export const IFW_STAKING_POOLS: IfwStakingPool[] = [
  { id: 'stk-01', name: 'Ecosystem Genesis Pool (30 Days)', durationDays: 30, apyPercent: 12.5, totalStaked: 14200000, participants: 28400, status: 'Active' },
  { id: 'stk-02', name: 'Fintech Liquidity Vault (90 Days)', durationDays: 90, apyPercent: 18.0, totalStaked: 18900000, participants: 39100, status: 'Active' },
  { id: 'stk-03', name: 'Master Validator Lockup (365 Days)', durationDays: 365, apyPercent: 26.5, totalStaked: 12100000, participants: 8420, status: 'Active' },
];

export const STAFF_ROSTER: StaffProfile[] = [
  { id: 'st-01', name: 'Dr. Marcus Vance', department: 'Executive', title: 'Chief Executive Officer', attendanceRate: 98.8, performanceScore: 98, payrollStatus: 'Disbursed', monthlySalary: '$38,000' },
  { id: 'st-02', name: 'Engr. Tariq Al-Mansoor', department: 'Engineering', title: 'Chief Technology Officer', attendanceRate: 99.2, performanceScore: 97, payrollStatus: 'Disbursed', monthlySalary: '$28,500' },
  { id: 'st-03', name: 'Amina Bello-Kalu', department: 'Operations', title: 'Chief Operating Officer', attendanceRate: 99.0, performanceScore: 96, payrollStatus: 'Disbursed', monthlySalary: '$26,000' },
  { id: 'st-04', name: 'Henrik Lindqvist', department: 'Finance', title: 'Chief Financial Officer', attendanceRate: 97.9, performanceScore: 97, payrollStatus: 'Disbursed', monthlySalary: '$27,000' },
  { id: 'st-05', name: 'Barrister Folake Adeleke', department: 'Risk & Compliance', title: 'Chief Compliance Officer', attendanceRate: 100.0, performanceScore: 99, payrollStatus: 'Disbursed', monthlySalary: '$24,500' },
  { id: 'st-06', name: 'Viktor Zimmerman', department: 'Risk & Compliance', title: 'Chief Risk Officer', attendanceRate: 98.4, performanceScore: 95, payrollStatus: 'Disbursed', monthlySalary: '$24,000' },
  { id: 'st-07', name: 'Zack Chen', department: 'Engineering', title: 'Lead Architect', attendanceRate: 99.4, performanceScore: 98, payrollStatus: 'Disbursed', monthlySalary: '$18,500' },
  { id: 'st-08', name: 'Farida Shehu', department: 'Legal', title: 'Senior Legal Counsel', attendanceRate: 98.2, performanceScore: 94, payrollStatus: 'Disbursed', monthlySalary: '$16,000' },
];

export const AUDIT_CONTROLS: InternalAuditItem[] = [
  { id: 'aud-01', controlCode: 'PCI-REQ-3.4', framework: 'PCI-DSS v4.0', controlName: 'PAN Cryptographic Truncation & Encryption in Flight', status: 'Compliant', lastAudited: 'Sep 10, 2026', auditorNotes: 'AES-256-GCM enforced across all ingress and internal microservices.' },
  { id: 'aud-02', controlCode: 'ISO-A.9.2', framework: 'ISO/IEC 27001', controlName: 'User Access Provisioning & Privileged Identity Management', status: 'Compliant', lastAudited: 'Sep 08, 2026', auditorNotes: 'FIDO2 WebAuthn hardware tokens enforced on root control panels.' },
  { id: 'aud-03', controlCode: 'SOC2-CC6.1', framework: 'SOC 2 Type II', controlName: 'Logical & Perimeter Firewall Rule Governance', status: 'Tested & Verified', lastAudited: 'Sep 14, 2026', auditorNotes: 'Quarterly penetration test clean report with zero critical or high vulnerabilities.' },
  { id: 'aud-04', controlCode: 'CBN-CIRC-2025', framework: 'CBN Guidelines', controlName: 'Settlement Account Daily Liquidity Buffer (≥ 15%)', status: 'Compliant', lastAudited: 'Today 00:00 UTC', auditorNotes: 'Buffer maintained at 24.8%, exceeding regulatory minimum.' },
];

export const PRIVACY_REQUESTS: DataPrivacyRequest[] = [
  { id: 'dsar-101', applicantName: 'Mustapha Sani', requestType: 'Right to Access', submissionDate: 'Sep 16, 2026', deadlineDate: 'Oct 16, 2026', status: 'Processing', dpoDecision: 'Pending Analysis' },
  { id: 'dsar-102', applicantName: 'Helen Braithwaite', requestType: 'Right to be Forgotten', submissionDate: 'Sep 12, 2026', deadlineDate: 'Oct 12, 2026', status: 'Completed', dpoDecision: 'Granted' },
  { id: 'dsar-103', applicantName: 'Ahmed Kabir', requestType: 'Data Portability', submissionDate: 'Sep 09, 2026', deadlineDate: 'Oct 09, 2026', status: 'Completed', dpoDecision: 'Granted' },
];

export const ECOSYSTEM_PARTNERS: EcosystemPartner[] = [
  { id: 'part-01', name: 'Zenith Commercial Bank PLC', category: 'Commercial Bank', integrationType: 'Direct Core NIP Switching', volumeMonth: 142000000, commissionRate: '0.25%', outstandingBalance: 420000, settlementStatus: 'Pending Clearing' },
  { id: 'part-02', name: 'Access Bank Group', category: 'Commercial Bank', integrationType: 'Treasury & FX Liquidity Rails', volumeMonth: 98000000, commissionRate: '0.22%', outstandingBalance: 310000, settlementStatus: 'Pending Clearing' },
  { id: 'part-03', name: '9PSB Payment Service Bank', category: 'PSB', integrationType: 'Agency Banking & USSD Rails', volumeMonth: 84000000, commissionRate: '0.40%', outstandingBalance: 280000, settlementStatus: 'Settled' },
  { id: 'part-04', name: 'Lapomax Microfinance Bank', category: 'MFB', integrationType: 'Sub-tier Rural Disbursal Netting', volumeMonth: 31000000, commissionRate: '0.50%', outstandingBalance: 95000, settlementStatus: 'Settled' },
  { id: 'part-05', name: 'Eko Electricity Distribution (EKEDC)', category: 'Utility Biller', integrationType: 'Power Token API Gateway', volumeMonth: 24000000, commissionRate: '1.20%', outstandingBalance: 145000, settlementStatus: 'Pending Clearing' },
  { id: 'part-06', name: 'MTN & Airtel Airtime Aggregator', category: 'Utility Biller', integrationType: 'Direct Telco Top-up Switch', volumeMonth: 48000000, commissionRate: '2.50%', outstandingBalance: 610000, settlementStatus: 'Pending Clearing' },
  { id: 'part-07', name: 'ShopRite Pan-Africa Hypermarkets', category: 'Retail Merchant', integrationType: 'In-store Dynamic QR Checkout', volumeMonth: 65000000, commissionRate: '1.40%', outstandingBalance: 520000, settlementStatus: 'Settled' },
];

export const IFW_COIN_METRICS = {
  priceUsd: 0.4852,
  priceChange24h: 8.4,
  marketCap: 165900000,
  totalSupply: 1000000000,
  circulatingSupply: 342000000,
  stakedCoins: 180000000,
  burnedCoins: 25000000,
  tradingVolume24h: 12400000,
  totalStakers: 48290,
  rewardsDistributedUsd: 4200000,
};

export const STAKING_POOLS = [
  { id: 'sp-1', name: 'Flexible Liquidity Vault', duration: 'Flexible (No Lock)', apy: 6.5, totalStaked: 45000000, participants: 24100 },
  { id: 'sp-2', name: '90-Day Growth Lockup', duration: '90-Day Lock', apy: 12.0, totalStaked: 65000000, participants: 16400 },
  { id: 'sp-3', name: '365-Day Governance Vault', duration: '365-Day Term', apy: 18.5, totalStaked: 70000000, participants: 7790 },
];

export const TOKEN_BURNS: TokenBurnEvent[] = [
  { id: 'tb-01', txHash: '0x8f21...99e4', amount: 5000000, usdValue: 2426000, burnedAt: 'Sep 01, 2026', quarter: 'Q2 2026 Buyback' },
  { id: 'tb-02', txHash: '0x3c90...11a2', amount: 8000000, usdValue: 3600000, burnedAt: 'Jun 01, 2026', quarter: 'Q1 2026 Buyback' },
  { id: 'tb-03', txHash: '0x1a84...ff39', amount: 12000000, usdValue: 4800000, burnedAt: 'Mar 01, 2026', quarter: 'Q4 2025 Buyback' },
];

export const SECURITY_AUDIT_LOGS: SecurityAuditLog[] = [
  { id: 'sec-01', operator: 'tariq.mansoor@ifuturewallet.com', action: 'WAF Rule Update (Geo-blocking bypass mitigations)', subsystem: 'Cloudflare Edge WAF', ipAddress: '10.0.4.12', severity: 'Medium', timestamp: '14 mins ago' },
  { id: 'sec-02', operator: 'sys-automated-guard', action: 'Suspicious IP Cluster Ban (38 nodes)', subsystem: 'AWS Shield Advanced', ipAddress: '185.220.101.0/24', severity: 'High', timestamp: '42 mins ago' },
  { id: 'sec-03', operator: 'folake.adeleke@ifuturewallet.com', action: 'AML Case Escalation to Central Bank FIU', subsystem: 'Compliance Sentinel', ipAddress: '10.0.1.88', severity: 'High', timestamp: '1 hour ago' },
  { id: 'sec-04', operator: 'marcus.vance@ifuturewallet.com', action: 'Board Resolution RES-2026-089 Ratification Key Sign', subsystem: 'Board Governance Ledger', ipAddress: '10.0.0.1', severity: 'Low', timestamp: '3 hours ago' },
  { id: 'sec-05', operator: 'zack.chen@ifuturewallet.com', action: 'Core Switch v4.18.2 Hotfix Canary Deploy', subsystem: 'Kubernetes Production Node', ipAddress: '10.240.0.4', severity: 'Medium', timestamp: '5 hours ago' },
];

export const EMPLOYEES_LIST: EmployeeRecord[] = [
  { id: 'emp-01', name: 'Dr. Marcus Vance', department: 'Executive', role: 'Chief Executive Officer', walletAddress: '0x71A...991B', salary: 38000, workMode: 'On-site', status: 'Active on Duty' },
  { id: 'emp-02', name: 'Engr. Tariq Al-Mansoor', department: 'Engineering', role: 'Chief Technology Officer', walletAddress: '0x88C...334A', salary: 28500, workMode: 'On-site', status: 'Active on Duty' },
  { id: 'emp-03', name: 'Amina Bello-Kalu', department: 'Operations', role: 'Chief Operating Officer', walletAddress: '0x44B...119F', salary: 26000, workMode: 'On-site', status: 'Active on Duty' },
  { id: 'emp-04', name: 'Henrik Lindqvist', department: 'Finance', role: 'Chief Financial Officer', walletAddress: '0x12E...772D', salary: 27000, workMode: 'On-site', status: 'Active on Duty' },
  { id: 'emp-05', name: 'Barrister Folake Adeleke', department: 'Compliance & Legal', role: 'Chief Compliance Officer', walletAddress: '0x99F...661C', salary: 24500, workMode: 'On-site', status: 'Active on Duty' },
  { id: 'emp-06', name: 'Alhaji Mansur Garba', department: 'Field Operations', role: 'Regional Manager (North West)', walletAddress: '0x55A...884E', salary: 21000, workMode: 'Hybrid', status: 'Active on Duty' },
  { id: 'emp-07', name: 'Zack Chen', department: 'Engineering', role: 'Principal Core Architect', walletAddress: '0x33D...221B', salary: 18500, workMode: 'Remote', status: 'Active on Duty' },
  { id: 'emp-08', name: 'Sarah Olatunji', department: 'Customer Success', role: 'Head of Customer Experience', walletAddress: '0x66B...449A', salary: 14000, workMode: 'On-site', status: 'Active on Duty' },
];

export const PLATFORM_FEES: PlatformFeeConfig = {
  depositFeePercent: 0.0,
  withdrawalFeePercent: 1.2,
  p2pTransferFeePercent: 0.5,
  billPaymentCommissionPercent: 1.5,
  merchantMdrPercent: 1.8,
  ifwCoinDiscountPercent: 50,
};

export const CURRENCIES_CONFIG: CurrencyConfig[] = [
  { code: 'USD', name: 'United States Dollar', symbol: '$', exchangeRateToUsd: 1.0, enabled: true },
  { code: 'NGN', name: 'Nigerian Naira', symbol: '₦', exchangeRateToUsd: 1580.0, enabled: true },
  { code: 'GBP', name: 'British Pound Sterling', symbol: '£', exchangeRateToUsd: 0.76, enabled: true },
  { code: 'EUR', name: 'Euro', symbol: '€', exchangeRateToUsd: 0.91, enabled: true },
  { code: 'IFW', name: 'iFutureWallet Coin', symbol: '⟠', exchangeRateToUsd: 0.4852, enabled: true },
];

