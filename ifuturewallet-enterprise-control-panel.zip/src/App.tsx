import { useState, useEffect } from 'react';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { CeoDashboard } from './components/views/CeoDashboard';
import { BoardDashboard } from './components/views/BoardDashboard';
import { CtoDashboard } from './components/views/CtoDashboard';
import { CooDashboard } from './components/views/CooDashboard';
import { CfoDashboard } from './components/views/CfoDashboard';
import { CcoDashboard } from './components/views/CcoDashboard';
import { CroDashboard } from './components/views/CroDashboard';
import { LegalDashboard } from './components/views/LegalDashboard';
import { PartnersDashboard } from './components/views/PartnersDashboard';
import { IfwCoinDashboard } from './components/views/IfwCoinDashboard';
import { SecurityDashboard } from './components/views/SecurityDashboard';
import { GrowthDashboard } from './components/views/GrowthDashboard';
import { HrDashboard } from './components/views/HrDashboard';
import { SettingsDashboard } from './components/views/SettingsDashboard';

import { GlobalSearchModal } from './components/modals/GlobalSearchModal';
import { ApiTesterModal } from './components/modals/ApiTesterModal';
import { ReportExportModal } from './components/modals/ReportExportModal';
import { KycReviewModal } from './components/modals/KycReviewModal';

import { DashboardRole, KycApplicant } from './types';
import { KYC_APPLICANTS } from './data/mockFintechData';

export default function App() {
  const [currentRole, setCurrentRole] = useState<DashboardRole>('ceo');
  const [currentViewId, setCurrentViewId] = useState<string>('ceo_overview');

  // Modals state
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isApiTesterOpen, setIsApiTesterOpen] = useState(false);
  const [apiTesterProduct, setApiTesterProduct] = useState<'Wallet API' | 'Payment API' | 'Virtual Account API' | 'KYC API'>('Wallet API');
  const [isReportExportOpen, setIsReportExportOpen] = useState(false);
  const [selectedKycApplicant, setSelectedKycApplicant] = useState<KycApplicant | null>(null);

  // Global hotkey for quick search
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setIsSearchOpen(true);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const handleRoleChange = (role: DashboardRole) => {
    setCurrentRole(role);
    const defaultViewMap: Record<string, string> = {
      ceo: 'ceo_overview',
      board: 'board_portal',
      cto: 'tech_command',
      coo: 'regional_hierarchy',
      cfo: 'treasury',
      cco: 'kyc_verification',
      cro: 'fraud_sentinel',
      legal: 'contract_management',
      partners: 'banking_partners',
      ifw_coin: 'coin_overview',
      security: 'security_dashboard',
      growth: 'user_acquisition',
      hr: 'employee_management',
      settings: 'platform_settings',
    };
    setCurrentViewId(defaultViewMap[role] || 'ceo_overview');
  };

  const handleSelectView = (viewId: string) => {
    setCurrentViewId(viewId);
  };

  const handleOpenApiTester = (product?: string) => {
    if (product === 'Payment API' || product === 'Virtual Account API' || product === 'KYC API') {
      setApiTesterProduct(product);
    } else {
      setApiTesterProduct('Wallet API');
    }
    setIsApiTesterOpen(true);
  };

  const handleOpenKycModal = (applicant: KycApplicant) => {
    setSelectedKycApplicant(applicant);
  };

  const handleKycActionComplete = (applicantId: string, newStatus: 'Verified' | 'Rejected' | 'High-Risk Escalated') => {
    const applicant = KYC_APPLICANTS.find(a => a.id === applicantId);
    if (applicant) {
      applicant.status = newStatus;
    }
    setSelectedKycApplicant(null);
  };

  // Render main active view based on role
  const renderDashboardView = () => {
    switch (currentRole) {
      case 'ceo':
        return (
          <CeoDashboard
            onOpenReportExport={() => setIsReportExportOpen(true)}
            onNavigateToRole={(role) => handleRoleChange(role as DashboardRole)}
          />
        );
      case 'board':
        return (
          <BoardDashboard
            onOpenReportExport={() => setIsReportExportOpen(true)}
          />
        );
      case 'cto':
        return (
          <CtoDashboard
            onOpenApiTester={(product) => handleOpenApiTester(product)}
          />
        );
      case 'coo':
        return <CooDashboard />;
      case 'cfo':
        return <CfoDashboard />;
      case 'cco':
        return (
          <CcoDashboard
            onOpenKycModal={handleOpenKycModal}
            onOpenReportExport={() => setIsReportExportOpen(true)}
          />
        );
      case 'cro':
        return <CroDashboard />;
      case 'legal':
        return <LegalDashboard />;
      case 'partners':
        return <PartnersDashboard />;
      case 'ifw_coin':
        return <IfwCoinDashboard />;
      case 'security':
        return <SecurityDashboard />;
      case 'growth':
        return <GrowthDashboard />;
      case 'hr':
        return <HrDashboard />;
      case 'settings':
        return <SettingsDashboard />;
      default:
        return (
          <CeoDashboard
            onOpenReportExport={() => setIsReportExportOpen(true)}
            onNavigateToRole={(role) => handleRoleChange(role as DashboardRole)}
          />
        );
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-cyan-500/20 selection:text-cyan-200">
      {/* Top Header */}
      <Header
        currentRole={currentRole}
        onRoleChange={handleRoleChange}
        onOpenSearch={() => setIsSearchOpen(true)}
        onOpenApiTester={() => handleOpenApiTester()}
        onOpenReportExport={() => setIsReportExportOpen(true)}
        unreadAlertsCount={3}
      />

      {/* Main Shell: Sidebar + Content */}
      <div className="flex flex-1 overflow-hidden">
        {/* Navigation Sidebar */}
        <Sidebar
          currentRole={currentRole}
          currentViewId={currentViewId}
          onSelectRole={handleRoleChange}
          onSelectView={handleSelectView}
        />

        {/* Scrollable View Area */}
        <main className="flex-1 overflow-y-auto px-4 sm:px-6 lg:px-8 py-6 max-w-7xl mx-auto w-full">
          {renderDashboardView()}
        </main>
      </div>

      {/* Global Modals */}
      <GlobalSearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        onNavigate={(role) => handleRoleChange(role)}
      />

      <ApiTesterModal
        isOpen={isApiTesterOpen}
        onClose={() => setIsApiTesterOpen(false)}
        defaultProduct={apiTesterProduct}
      />

      <ReportExportModal
        isOpen={isReportExportOpen}
        onClose={() => setIsReportExportOpen(false)}
      />

      <KycReviewModal
        isOpen={!!selectedKycApplicant}
        applicant={selectedKycApplicant}
        onClose={() => setSelectedKycApplicant(null)}
        onActionComplete={handleKycActionComplete}
      />
    </div>
  );
}
